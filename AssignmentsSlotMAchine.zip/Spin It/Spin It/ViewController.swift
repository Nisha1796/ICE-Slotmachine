//
//  ViewController.swift
//  Spin It
//
//  Created by Nisha Gohil on 2021-01-23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var firstImage: UIImageView!
    @IBOutlet weak var secondImage: UIImageView!
    @IBOutlet weak var thirdImage: UIImageView!
    
    
    @IBOutlet weak var spinit: UIButton!
    
    @IBOutlet weak var forthImage: UIImageView!
    @IBAction func spin(_ sender: UIButton) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        firstImage.layer.cornerRadius = 60
        firstImage.clipsToBounds  = true
        firstImage.layer.borderColor = UIColor.systemYellow.cgColor
        firstImage.layer.borderWidth = 3
        
        secondImage.layer.cornerRadius = 60
        secondImage.clipsToBounds  = true
        secondImage.layer.borderColor = UIColor.systemYellow.cgColor
        secondImage.layer.borderWidth = 3
        
        thirdImage.layer.cornerRadius = 60
        thirdImage.clipsToBounds  = true
        thirdImage.layer.borderColor = UIColor.systemYellow.cgColor
        thirdImage.layer.borderWidth = 3
        
        forthImage.layer.cornerRadius = 80
        forthImage.clipsToBounds  = true
        forthImage.layer.borderColor = UIColor.systemYellow.cgColor
        forthImage.layer.borderWidth = 7
        
        spinit.layer.cornerRadius = 10
        spinit.clipsToBounds  = true
        spinit.layer.borderColor = UIColor.systemYellow.cgColor
        spinit.layer.borderWidth = 5
        
        

    }


}

